package Multi_lock;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Monitor {
	final Lock lock = new ReentrantLock();
	final Condition not_full = lock.newCondition();
	final Condition not_empty = lock.newCondition();
	Producto buf[];
	private int insert_l;
	public int pId = 0;
	private int n;
	private int front = 0;
	private int rear = 0;
	private int count = 0;
	volatile private Producto pr[] = null;
	
	public Monitor(int n, int m) {
		this.n = n;
		this.insert_l = m;
		this.buf = new Producto[n];
		this.pr = new Producto[m];
	}
	
	public void producir (Producto[] p, int Pid) throws InterruptedException{
		lock.lock();
		try {
			while (count > (n-insert_l)) not_full.await();
			
			for (int i = 0; i < insert_l; i++) {
				buf[rear] = p[i];
				System.out.println("Productor n�mero " + Pid + ": Producto n�mero " + p[i].id);
				rear = (rear + 1)%n;
				count++;
			}
			
			not_empty.signal();
		}finally {
			lock.unlock();
		}
		
	}
	public void consumir (int Cid) throws InterruptedException{
		lock.lock();
		try {
			Producto[] p = this.pr;
			while (count <= (n-insert_l)) not_empty.await();
			
			for (int i = 0; i < insert_l; i++) {
				this.pr[i] = null;
				p[i] = buf[front];
				front = (front + 1)%n;
				System.out.println("Consumidor n�mero " + Cid + ": Producto n�mero " + p[i].id);
				count--;
				
			}
			
			not_full.signal();
		}finally {
			lock.unlock();
		}
		
	}
}
