package Multi_lock;

import Multi_synchronized.Consumidor;
import Multi_synchronized.Monitor;
import Multi_synchronized.Productor;

public class Main {
	public static void main(String[] args) throws InterruptedException{
	int M = 10;
	int N = 5;
	int len = 10; //longitud del buffer
	int block = 3; //cantidad de productos producidos/consumidos a la vez
	Monitor monitor = new Monitor (len, block);
	Thread[] consumidores = new Thread[M];
	Thread[] productores = new Thread[N];
	
	
	for(int i = 0; i < N; i++) {
		productores[i] = new Productor(monitor, i, block);
		productores[i].start();
	}
	for(int i = 0; i < M; i++) {
		consumidores[i] = new Consumidor(monitor, i, block);
		consumidores[i].start();
	}
	
	for(int i = 0; i < N; i++) {
		productores[i].join();
	}
	for(int i = 0; i < M; i++) {
		consumidores[i].join();

	}}
}
