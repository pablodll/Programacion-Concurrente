package Multi_lock;

import Multi_synchronized.Monitor;
import Multi_synchronized.Producto;

public class Productor extends Thread{
	private Monitor data;
	public int id;
	private int n;
	
	public Productor(Monitor data, int id, int n) {
		this.data = data;
		this.id = id;
		this.n = n;
	}
	
	@Override
	public void run() {
		int i = 0;
		
		while(i < 10) {
			Producto prod[] = new Producto[n];
			for (int j = 0; j < n; j++) {
				Producto a = new Producto(data.pId++);
				prod[j] = a; // porque hacer que prod[i] = new Producto no iba
				}
			data.producir(prod, this.id);
			i++;	
			}
		}
		
	
}
