package Multi_lock;

import Multi_synchronized.Monitor;
import Multi_synchronized.Producto;

public class Consumidor extends Thread{
	private Monitor data;
	public int id;
	public int n;
	
	public Consumidor(Monitor data, int id, int n) {
		this.data = data;
		this.id = id;
		this.n = n;
	}
	
	@Override
	public void run() {
		int i = 0;
		
		while(i < 10) {
			
			Producto prod[] = new Producto[n];
			prod = data.consumir(this.id);
			i++;
		}
	}
}
