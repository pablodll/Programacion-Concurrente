package Multi_lock;

public class Producto {
	
	public int id;
	
	public Producto (int i) {
		this.id = i;
	}
}

