package MultiBufferLockCondition;

public class SharedMB {
	
	public int prodId = 0;
	
}
