package MultiBufferLockCondition;

public class Producto {
	
	public int id;
	
	public Producto(int id) {
		this.id = id;
	}
	
}
